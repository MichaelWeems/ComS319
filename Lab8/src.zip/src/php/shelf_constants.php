<?php
$shelfSize = 15;
$shelfCount = 5;
?>