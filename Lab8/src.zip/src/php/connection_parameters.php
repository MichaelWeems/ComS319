<?php
$username = "root";
$password = "root";
$dbServer = "localhost:3306"; 
$dbName   = "lab8";
?>