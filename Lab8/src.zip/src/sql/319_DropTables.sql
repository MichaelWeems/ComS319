set FOREIGN_KEY_CHECKS=0;

drop table Group8_users;

drop table Group8_books;

drop table Group8_bookCopy;

drop table Group8_loanHistory;

drop table Group8_shelves;

set FOREIGN_KEY_CHECKS=1;